// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAlkpIFnaBaeCCs2IzYrmKK6o-2i89BOZw",
  authDomain: "smartworld-ffc38.firebaseapp.com",
  projectId: "smartworld-ffc38",
  storageBucket: "smartworld-ffc38.appspot.com",
  messagingSenderId: "98437058404",
  appId: "1:98437058404:web:7225593fcc6b01099ff471"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export default app;